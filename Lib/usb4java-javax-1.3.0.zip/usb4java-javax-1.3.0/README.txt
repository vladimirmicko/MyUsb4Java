usb4java-javax 1.3.0
http://usb4java.org/usb4java-javax/
Copyright 2014 usb4java Team <http://usb4java.org/>
See LICENSE.md for licensing information.
------------------------------------------------------------------------------

The lib directory contains the following JAR files:

usb4java-javax.jar         (The usb4java extension for javax-usb)
usb-api-*.jar              (The javax-usb API library)

This is just an extension for the usb4java library so you also need the
usb4java main library and the libusb4java native libraries. See
http://usb4java.org/ for details.
